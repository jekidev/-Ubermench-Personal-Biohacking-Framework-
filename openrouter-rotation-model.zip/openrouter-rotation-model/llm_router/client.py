from __future__ import annotations

import asyncio
from dataclasses import dataclass
import json
import logging
import random
from typing import Any, AsyncIterator, Iterable

import httpx

from .catalog import ModelCatalog
from .config import RouterConfig
from .errors import AllRoutesFailed, LLMRouterError
from .health import HealthRegistry
from .models import ModelInfo

logger = logging.getLogger(__name__)
_RETRYABLE = {408, 409, 425, 429, 500, 502, 503, 504}


@dataclass(slots=True)
class LLMResponse:
    content: str
    model: str | None
    usage: dict[str, Any]
    raw: dict[str, Any]


class OpenRouterClient:
    """Framework-neutral async LLM router with discovery, rotation and failover."""

    def __init__(self, config: RouterConfig | None = None, *, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.config = config or RouterConfig.from_env()
        self.config.validate()
        self._client = httpx.AsyncClient(base_url=self.config.base_url, timeout=httpx.Timeout(self.config.timeout_seconds), transport=transport)
        self.catalog = ModelCatalog(self.config.base_url, self.config.api_keys[0], cache_path=self.config.cache_path, cache_ttl_seconds=self.config.cache_ttl_seconds, transport=transport)
        self.health = HealthRegistry(threshold=self.config.failure_threshold, cooldown_seconds=self.config.cooldown_seconds)
        self._cursor = 0
        self._lock = asyncio.Lock()

    async def __aenter__(self): return self
    async def __aexit__(self, *_): await self.aclose()
    async def aclose(self) -> None: await self._client.aclose()

    async def models(self, *, refresh: bool = False) -> list[ModelInfo]:
        if self.config.models:
            return [ModelInfo(id=mid, name=mid) for mid in self.config.models]
        return await self.catalog.select(free_only=self.config.free_only, min_context=self.config.min_context, include=self.config.include_models, exclude=self.config.exclude_models, limit=self.config.model_limit, force_refresh=refresh)

    async def _routes(self, override: list[str] | None = None) -> list[tuple[int, str, str]]:
        model_ids = override or [m.id for m in await self.models()]
        routes = [(ki, key, model) for model in model_ids for ki, key in enumerate(self.config.api_keys)]
        available = [r for r in routes if self.health.get(f"{r[0]}:{r[2]}").available]
        routes = available or routes
        async with self._lock:
            start = self._cursor % len(routes)
            self._cursor = (self._cursor + 1) % len(routes)
        return routes[start:] + routes[:start]

    def _headers(self, key: str) -> dict[str, str]:
        h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json", "X-OpenRouter-Title": self.config.app_name, "X-OpenRouter-Metadata": "enabled"}
        if self.config.site_url: h["HTTP-Referer"] = self.config.site_url
        return h

    def _body(self, messages, model, max_tokens, temperature, stream, extra_body):
        body = {"model": model, "messages": messages, "stream": stream, "max_completion_tokens": max_tokens or self.config.max_tokens}
        temp = self.config.temperature if temperature is None else temperature
        if temp is not None: body["temperature"] = temp
        if extra_body: body.update(extra_body)
        return body

    def _backoff(self, retry: int) -> float:
        base = self.config.retry_base_seconds * 2**retry
        return min(base + random.uniform(0, base * .25), 30)

    @staticmethod
    def _extract(data: dict[str, Any]) -> LLMResponse:
        try: content = data["choices"][0]["message"].get("content") or ""
        except (KeyError, IndexError, TypeError) as exc: raise LLMRouterError("Malformed response") from exc
        return LLMResponse(str(content), data.get("model"), data.get("usage") or {}, data)

    async def chat(self, messages: list[dict[str, Any]], *, models: list[str] | None = None, max_tokens: int | None = None, temperature: float | None = None, session_id: str | None = None, extra_body: dict[str, Any] | None = None) -> LLMResponse:
        if not messages: raise ValueError("messages cannot be empty")
        attempts = []
        for key_index, key, model in await self._routes(models):
            route = f"{key_index}:{model}"
            for retry in range(self.config.max_retries_per_route + 1):
                try:
                    body = self._body(messages, model, max_tokens, temperature, False, extra_body)
                    if session_id: body.setdefault("metadata", {})["session_id"] = session_id
                    res = await self._client.post("/chat/completions", headers=self._headers(key), json=body)
                    if res.status_code < 400:
                        self.health.success(route)
                        return self._extract(res.json())
                    err = res.text[:500]
                    attempts.append({"key_index": key_index, "model": model, "status": res.status_code, "error": err, "retry": retry})
                    self.health.failure(route, err, hard=res.status_code in {400, 401, 402, 403, 404})
                    if res.status_code not in _RETRYABLE: break
                    if retry < self.config.max_retries_per_route:
                        await asyncio.sleep(self._backoff(retry))
                except (httpx.TimeoutException, httpx.NetworkError) as exc:
                    attempts.append({"key_index": key_index, "model": model, "status": None, "error": type(exc).__name__, "retry": retry})
                    self.health.failure(route, type(exc).__name__)
                    if retry < self.config.max_retries_per_route: await asyncio.sleep(self._backoff(retry))
        raise AllRoutesFailed(attempts)

    async def stream(self, messages: list[dict[str, Any]], *, models: list[str] | None = None, max_tokens: int | None = None, temperature: float | None = None, extra_body: dict[str, Any] | None = None) -> AsyncIterator[str]:
        attempts = []
        for key_index, key, model in await self._routes(models):
            route = f"{key_index}:{model}"
            emitted = False
            try:
                body = self._body(messages, model, max_tokens, temperature, True, extra_body)
                async with self._client.stream("POST", "/chat/completions", headers=self._headers(key), json=body) as res:
                    if res.status_code >= 400:
                        err = (await res.aread()).decode(errors="replace")[:500]
                        attempts.append({"key_index": key_index, "model": model, "status": res.status_code, "error": err})
                        self.health.failure(route, err, hard=res.status_code in {400,401,402,403,404})
                        continue
                    async for line in res.aiter_lines():
                        if not line.startswith("data: "): continue
                        data = line[6:]
                        if data == "[DONE]": break
                        try: chunk = json.loads(data)
                        except json.JSONDecodeError: continue
                        token = ((chunk.get("choices") or [{}])[0].get("delta") or {}).get("content")
                        if token:
                            emitted = True
                            yield token
                self.health.success(route)
                return
            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                attempts.append({"key_index": key_index, "model": model, "status": None, "error": type(exc).__name__})
                self.health.failure(route, type(exc).__name__)
                if emitted:
                    raise LLMRouterError("Stream interrupted after output began; failover would duplicate text") from exc
        raise AllRoutesFailed(attempts)

    async def ask(self, prompt: str, *, system_prompt: str | None = None, history: Iterable[dict[str, Any]] | None = None, **kwargs: Any) -> LLMResponse:
        messages = []
        if system_prompt: messages.append({"role": "system", "content": system_prompt})
        if history: messages.extend(history)
        messages.append({"role": "user", "content": prompt})
        return await self.chat(messages, **kwargs)
