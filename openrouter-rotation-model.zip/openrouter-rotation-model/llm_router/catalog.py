from __future__ import annotations

import asyncio
import json
import time
from pathlib import Path
from typing import Iterable

import httpx

from .models import ModelInfo


class ModelCatalog:
    """Fetches, filters and caches OpenRouter's current model catalogue."""

    def __init__(self, base_url: str, api_key: str | None = None, *, cache_path: str | Path | None = None, cache_ttl_seconds: int = 3600, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.cache_path = Path(cache_path or ".cache/openrouter-models.json")
        self.cache_ttl_seconds = cache_ttl_seconds
        self._lock = asyncio.Lock()
        self._transport = transport

    def _read_cache(self) -> list[ModelInfo] | None:
        try:
            payload = json.loads(self.cache_path.read_text(encoding="utf-8"))
            if time.time() - float(payload["saved_at"]) > self.cache_ttl_seconds:
                return None
            return [ModelInfo.from_api(item) for item in payload["data"]]
        except (OSError, ValueError, KeyError, TypeError):
            return None

    def _write_cache(self, rows: list[dict]) -> None:
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.cache_path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"saved_at": time.time(), "data": rows}), encoding="utf-8")
        tmp.replace(self.cache_path)

    async def fetch_all(self, *, force: bool = False) -> list[ModelInfo]:
        if not force and (cached := self._read_cache()) is not None:
            return cached
        async with self._lock:
            if not force and (cached := self._read_cache()) is not None:
                return cached
            headers = {"Authorization": f"Bearer {self.api_key}"} if self.api_key else {}
            async with httpx.AsyncClient(base_url=self.base_url, timeout=30, transport=self._transport) as client:
                response = await client.get("/models", headers=headers)
                response.raise_for_status()
                rows = response.json().get("data") or []
            self._write_cache(rows)
            return [ModelInfo.from_api(row) for row in rows if row.get("id")]

    async def select(self, *, free_only: bool = True, text_only: bool = True, required_parameters: Iterable[str] = (), min_context: int = 0, include: Iterable[str] = (), exclude: Iterable[str] = (), limit: int | None = None, force_refresh: bool = False) -> list[ModelInfo]:
        models = await self.fetch_all(force=force_refresh)
        include_l = tuple(x.lower() for x in include)
        exclude_l = tuple(x.lower() for x in exclude)
        required = set(required_parameters)

        def allowed(m: ModelInfo) -> bool:
            haystack = f"{m.id} {m.name}".lower()
            return (
                (not free_only or m.is_free)
                and (not text_only or "text" in m.output_modalities or not m.output_modalities)
                and m.context_length >= min_context
                and required.issubset(set(m.supported_parameters))
                and (not include_l or any(x in haystack for x in include_l))
                and not any(x in haystack for x in exclude_l)
            )

        chosen = [m for m in models if allowed(m)]
        chosen.sort(key=lambda m: (m.context_length, m.name), reverse=True)
        return chosen[:limit] if limit else chosen
