from __future__ import annotations
import asyncio
from typing import Any
from .client import OpenRouterClient, LLMResponse
from .config import RouterConfig


class SyncOpenRouterClient:
    """Synchronous facade for scripts, Flask, Django and desktop apps."""
    def __init__(self, config: RouterConfig | None = None): self.config = config
    def chat(self, messages: list[dict[str, Any]], **kwargs: Any) -> LLMResponse:
        async def run():
            async with OpenRouterClient(self.config) as client: return await client.chat(messages, **kwargs)
        return asyncio.run(run())
    def ask(self, prompt: str, **kwargs: Any) -> LLMResponse:
        async def run():
            async with OpenRouterClient(self.config) as client: return await client.ask(prompt, **kwargs)
        return asyncio.run(run())
