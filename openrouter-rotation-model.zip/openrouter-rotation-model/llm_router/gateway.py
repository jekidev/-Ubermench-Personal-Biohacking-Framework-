from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from .client import OpenRouterClient
from .errors import AllRoutesFailed, LLMRouterError

router: OpenRouterClient | None = None
STATIC_DIR = Path(__file__).resolve().parent.parent / "web"


@asynccontextmanager
async def lifespan(_: FastAPI):
    global router
    router = OpenRouterClient()
    yield
    await router.aclose()


app = FastAPI(title="OpenRouter Rotation Chat", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

if STATIC_DIR.exists():
    app.mount("/assets", StaticFiles(directory=STATIC_DIR), name="assets")


@app.get("/")
async def index():
    index_file = STATIC_DIR / "index.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="Frontend not installed")
    return FileResponse(index_file)


@app.get("/health")
async def health():
    assert router is not None
    return {"ok": True, "routes": router.health.snapshot()}


@app.get("/api/models")
@app.get("/v1/models")
async def models(refresh: bool = False):
    assert router is not None
    items = await router.models(refresh=refresh)
    return {
        "object": "list",
        "data": [
            {
                "id": model.id,
                "name": model.name or model.id,
                "context_length": model.context_length,
                "owned_by": model.id.split("/")[0],
            }
            for model in items
        ],
    }


def _validated_messages(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list) or not value:
        raise HTTPException(status_code=422, detail="messages must be a non-empty list")
    clean: list[dict[str, Any]] = []
    for item in value[-40:]:
        if not isinstance(item, dict):
            continue
        role = item.get("role")
        content = item.get("content")
        if role in {"system", "user", "assistant"} and isinstance(content, str) and content.strip():
            clean.append({"role": role, "content": content[:30000]})
    if not clean:
        raise HTTPException(status_code=422, detail="No valid messages supplied")
    return clean


@app.post("/api/chat")
async def browser_chat(request: Request):
    assert router is not None
    body = await request.json()
    messages = _validated_messages(body.get("messages"))
    requested = body.get("model")
    selected_models = None if not requested or requested in {"auto", "openrouter/free"} else [str(requested)]

    try:
        result = await router.chat(
            messages,
            models=selected_models,
            max_tokens=min(int(body.get("max_tokens", 1200)), 4000),
            temperature=float(body.get("temperature", 0.7)),
            session_id=str(body.get("session_id", "web-chat"))[:100],
        )
        return {
            "content": result.content,
            "model": result.model,
            "usage": result.usage,
        }
    except AllRoutesFailed as exc:
        raise HTTPException(status_code=503, detail={"message": "All configured routes failed", "attempts": exc.attempts[-8:]}) from exc
    except (LLMRouterError, ValueError) as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.post("/v1/chat/completions")
async def completions(request: Request):
    assert router is not None
    body = await request.json()
    messages = _validated_messages(body.pop("messages", None))
    requested = body.pop("model", None)
    models_override = None if not requested or requested in {"auto", "openrouter/free"} else [requested]
    max_tokens = body.pop("max_tokens", body.pop("max_completion_tokens", None))
    temperature = body.pop("temperature", None)
    result = await router.chat(
        messages,
        models=models_override,
        max_tokens=max_tokens,
        temperature=temperature,
        extra_body=body,
    )
    return JSONResponse(result.raw)
