def gateway():
    import uvicorn
    uvicorn.run("llm_router.gateway:app", host="0.0.0.0", port=8000)
