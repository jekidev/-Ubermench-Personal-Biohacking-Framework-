from __future__ import annotations

from dataclasses import dataclass
import time


@dataclass(slots=True)
class RouteHealth:
    failures: int = 0
    successes: int = 0
    cooldown_until: float = 0.0
    last_error: str | None = None

    @property
    def available(self) -> bool:
        return time.monotonic() >= self.cooldown_until


class HealthRegistry:
    def __init__(self, *, threshold: int = 2, cooldown_seconds: float = 60.0) -> None:
        self.threshold = threshold
        self.cooldown_seconds = cooldown_seconds
        self._routes: dict[str, RouteHealth] = {}

    def get(self, route: str) -> RouteHealth:
        return self._routes.setdefault(route, RouteHealth())

    def success(self, route: str) -> None:
        state = self.get(route)
        state.successes += 1
        state.failures = 0
        state.cooldown_until = 0
        state.last_error = None

    def failure(self, route: str, error: str, *, hard: bool = False) -> None:
        state = self.get(route)
        state.failures += 1
        state.last_error = error
        if hard or state.failures >= self.threshold:
            state.cooldown_until = time.monotonic() + self.cooldown_seconds

    def snapshot(self) -> dict[str, dict]:
        now = time.monotonic()
        return {route: {"failures": s.failures, "successes": s.successes, "cooldown_remaining": max(0.0, s.cooldown_until-now), "last_error": s.last_error} for route, s in self._routes.items()}
