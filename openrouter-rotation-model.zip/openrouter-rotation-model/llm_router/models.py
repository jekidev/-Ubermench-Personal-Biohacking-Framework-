from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True, frozen=True)
class ModelInfo:
    id: str
    name: str = ""
    description: str = ""
    context_length: int = 0
    prompt_price: float = 0.0
    completion_price: float = 0.0
    request_price: float = 0.0
    supported_parameters: tuple[str, ...] = ()
    input_modalities: tuple[str, ...] = ()
    output_modalities: tuple[str, ...] = ()
    raw: dict[str, Any] = field(default_factory=dict, compare=False, hash=False)

    @property
    def is_free(self) -> bool:
        return self.prompt_price == self.completion_price == self.request_price == 0.0

    @classmethod
    def from_api(cls, data: dict[str, Any]) -> "ModelInfo":
        pricing = data.get("pricing") or {}
        architecture = data.get("architecture") or {}

        def price(name: str) -> float:
            try:
                return float(pricing.get(name) or 0)
            except (TypeError, ValueError):
                return 0.0

        return cls(
            id=str(data.get("id") or ""),
            name=str(data.get("name") or data.get("id") or ""),
            description=str(data.get("description") or ""),
            context_length=int(data.get("context_length") or 0),
            prompt_price=price("prompt"),
            completion_price=price("completion"),
            request_price=price("request"),
            supported_parameters=tuple(data.get("supported_parameters") or ()),
            input_modalities=tuple(architecture.get("input_modalities") or ()),
            output_modalities=tuple(architecture.get("output_modalities") or ()),
            raw=data,
        )
