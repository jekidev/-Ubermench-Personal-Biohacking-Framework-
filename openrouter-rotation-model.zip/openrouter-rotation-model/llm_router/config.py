from __future__ import annotations

from dataclasses import dataclass, field
import os


def _csv_env(name: str) -> list[str]:
    return [item.strip() for item in os.getenv(name, "").split(",") if item.strip()]


def _bool_env(name: str, default: bool) -> bool:
    value = os.getenv(name)
    return default if value is None else value.strip().lower() in {"1", "true", "yes", "on"}


@dataclass(slots=True)
class RouterConfig:
    api_keys: list[str]
    models: list[str] = field(default_factory=list)
    base_url: str = "https://openrouter.ai/api/v1"
    timeout_seconds: float = 45.0
    max_retries_per_route: int = 1
    retry_base_seconds: float = 0.75
    app_name: str = "Modular Python LLM Router"
    site_url: str | None = None
    max_tokens: int = 1024
    temperature: float | None = None
    auto_discover: bool = True
    free_only: bool = True
    model_limit: int = 50
    min_context: int = 0
    include_models: list[str] = field(default_factory=list)
    exclude_models: list[str] = field(default_factory=list)
    cache_path: str = ".cache/openrouter-models.json"
    cache_ttl_seconds: int = 3600
    cooldown_seconds: float = 60.0
    failure_threshold: int = 2

    @classmethod
    def from_env(cls) -> "RouterConfig":
        keys = _csv_env("OPENROUTER_API_KEYS")
        if not keys and (single := os.getenv("OPENROUTER_API_KEY", "").strip()):
            keys = [single]
        if not keys:
            raise ValueError("Set OPENROUTER_API_KEY or OPENROUTER_API_KEYS.")
        temp = os.getenv("OPENROUTER_TEMPERATURE", "").strip()
        return cls(
            api_keys=keys,
            models=_csv_env("OPENROUTER_MODELS"),
            base_url=os.getenv("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1").rstrip("/"),
            timeout_seconds=float(os.getenv("OPENROUTER_TIMEOUT", "45")),
            max_retries_per_route=int(os.getenv("OPENROUTER_RETRIES", "1")),
            retry_base_seconds=float(os.getenv("OPENROUTER_RETRY_BASE", "0.75")),
            app_name=os.getenv("OPENROUTER_APP_NAME", "Modular Python LLM Router"),
            site_url=os.getenv("OPENROUTER_SITE_URL") or None,
            max_tokens=int(os.getenv("OPENROUTER_MAX_TOKENS", "1024")),
            temperature=float(temp) if temp else None,
            auto_discover=_bool_env("OPENROUTER_AUTO_DISCOVER", True),
            free_only=_bool_env("OPENROUTER_FREE_ONLY", True),
            model_limit=int(os.getenv("OPENROUTER_MODEL_LIMIT", "50")),
            min_context=int(os.getenv("OPENROUTER_MIN_CONTEXT", "0")),
            include_models=_csv_env("OPENROUTER_INCLUDE_MODELS"),
            exclude_models=_csv_env("OPENROUTER_EXCLUDE_MODELS"),
            cache_path=os.getenv("OPENROUTER_CACHE_PATH", ".cache/openrouter-models.json"),
            cache_ttl_seconds=int(os.getenv("OPENROUTER_CACHE_TTL", "3600")),
            cooldown_seconds=float(os.getenv("OPENROUTER_COOLDOWN", "60")),
            failure_threshold=int(os.getenv("OPENROUTER_FAILURE_THRESHOLD", "2")),
        )

    def validate(self) -> None:
        if not self.api_keys:
            raise ValueError("At least one API key is required.")
        if not self.models and not self.auto_discover:
            raise ValueError("Configure models or enable auto discovery.")
        if self.max_retries_per_route < 0:
            raise ValueError("Retries cannot be negative.")
