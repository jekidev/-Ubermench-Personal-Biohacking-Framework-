import asyncio

from llm_router import OpenRouterClient


async def main() -> None:
    async with OpenRouterClient() as llm:
        response = await llm.ask(
            "Forklar dependency injection kort på dansk.",
            system_prompt="Du er en præcis softwarearkitekt.",
            session_id="demo-conversation-1",
        )
        print(response.content)
        print("Model:", response.model)
        print("Usage:", response.usage)


if __name__ == "__main__":
    asyncio.run(main())
