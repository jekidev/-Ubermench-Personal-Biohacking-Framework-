"""
Drop-in replacement pattern for nomos-bot/services/openrouter.py.

The NOMOS-specific responsibilities stay here:
- database-backed system prompt
- chat history
- agent context
- delegation parsing

The generic network/routing behavior lives in llm_router.
"""

import json
import re

import database as db
from llm_router import OpenRouterClient

DEFAULT_SYSTEM_PROMPT = """You are NOMOS, an AI group moderator.
Keep responses concise and use the admin's language.
"""


def get_system_prompt() -> str:
    return db.get_setting("ai_system_prompt", DEFAULT_SYSTEM_PROMPT)


def _build_agent_context() -> str:
    agents = db.get_all_agents(active_only=True)
    if not agents:
        return ""

    lines = [
        "## Available Sub-Agents",
        "Delegate only when a specialized agent clearly fits.",
    ]
    for agent in agents:
        lines.append(
            f"- {agent['name']}: {agent['description'] or 'general purpose'}"
        )
    lines.append(
        'Reply only with ```delegate\n'
        '{"agent":"<name>","instruction":"<task>"}\n``` when delegating.'
    )
    return "\n".join(lines)


def _parse_delegation(text: str) -> dict | None:
    match = re.search(r"```delegate\s*(\{.*?\})\s*```", text, re.DOTALL)
    if not match:
        return None
    try:
        data = json.loads(match.group(1))
    except json.JSONDecodeError:
        return None

    if isinstance(data.get("agent"), str) and isinstance(
        data.get("instruction"), str
    ):
        return {
            "delegate": True,
            "agent": data["agent"],
            "instruction": data["instruction"],
        }
    return None


async def ask_ai(
    user_message: str,
    context: str = "",
    history_limit: int = 20,
) -> str | dict:
    messages = [{"role": "system", "content": get_system_prompt()}]

    agent_context = _build_agent_context()
    if agent_context:
        messages.append({"role": "system", "content": agent_context})
    if context:
        messages.append(
            {"role": "system", "content": f"Current data context:\n{context}"}
        )

    messages.extend(db.get_chat_history(history_limit))
    messages.append({"role": "user", "content": user_message})

    async with OpenRouterClient() as llm:
        result = await llm.chat(
            messages,
            session_id="nomos-admin-chat",
        )

    db.save_chat_turn("user", user_message)
    db.save_chat_turn("assistant", result.content)

    return _parse_delegation(result.content) or result.content
