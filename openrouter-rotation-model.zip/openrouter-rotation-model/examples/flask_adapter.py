from flask import Flask, jsonify, request
from llm_router import SyncOpenRouterClient
app = Flask(__name__)
llm = SyncOpenRouterClient()
@app.post('/api/chat')
def chat():
    result = llm.chat(request.json['messages'])
    return jsonify({'reply': result.content, 'model': result.model})
