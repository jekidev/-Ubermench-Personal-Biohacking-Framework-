// Point any browser/mobile/desktop chat UI at the local gateway.
export async function askLLM(messages, baseUrl = "http://localhost:8000") {
  const response = await fetch(`${baseUrl}/v1/chat/completions`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model: "auto", messages })
  });
  if (!response.ok) throw new Error(await response.text());
  const data = await response.json();
  return data.choices[0].message.content;
}
