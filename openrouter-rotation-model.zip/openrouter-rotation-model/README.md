# Universal Modular OpenRouter Router

A framework-neutral Python package that dynamically fetches OpenRouter's current model catalogue, selects free models, rotates across models, retries transient failures and temporarily cools down unhealthy routes.

## What it provides

- Dynamic `GET /models` catalogue with disk cache.
- Optional free-only filtering, inclusion/exclusion filters and minimum context.
- Per-model and per-key round-robin rotation.
- Retry, exponential backoff, cooldown and structured failure history.
- Async client, sync client and OpenAI-compatible HTTP gateway.
- Streaming that only fails over before output begins, preventing duplicated partial answers.
- No Hugging Face weight downloads; local inference can be integrated separately without forcing multi-GB downloads into a web host.

## Install

```bash
pip install -e .
pip install -e '.[gateway]'
```

Set `OPENROUTER_API_KEY` as an environment secret. Never place it in frontend JavaScript.

## Python async

```python
from llm_router import OpenRouterClient

async with OpenRouterClient() as llm:
    result = await llm.ask("Hello")
    print(result.content, result.model)
```

## Python sync

```python
from llm_router import SyncOpenRouterClient
result = SyncOpenRouterClient().ask("Hello")
```

## Universal website/app integration

Run the OpenAI-compatible gateway:

```bash
uvicorn llm_router.gateway:app --host 0.0.0.0 --port 8000
```

Existing OpenAI-compatible clients can then use:

- Base URL: `http://your-server:8000/v1`
- Model: `auto`
- Endpoint: `/chat/completions`

Use `examples/browser.js` only against your own backend gateway. The OpenRouter key remains server-side.

## Model behaviour

With `OPENROUTER_AUTO_DISCOVER=true`, the router refreshes OpenRouter's model catalogue and selects available models based on configuration. Set `OPENROUTER_MODELS` for a fixed ordered list. Model IDs are not hard-coded because free offerings change.

## Existing chatbot migration

Replace the old provider call with `OpenRouterClient.chat(messages)`, or point the application's existing OpenAI SDK at the gateway. Conversation storage remains the responsibility of the host application, so the module works with Flask, FastAPI, Django, Telegram, Discord, mobile backends and desktop apps.

## Included web chat

This package now includes a responsive browser chat at `/`.

```bash
cp .env.example .env
# Add your key to .env
pip install -r requirements.txt
uvicorn llm_router.gateway:app --reload
```

Open `http://localhost:8000`. The browser only calls `/api/chat`; the OpenRouter key remains in the server environment.

### Docker

```bash
docker build -t rotation-chat .
docker run --env-file .env -p 8000:8000 rotation-chat
```

### Deploy

- Render: connect the repository, use the included `render.yaml`, and add `OPENROUTER_API_KEY` as a secret.
- Railway/Fly.io/other Docker hosts: deploy the included `Dockerfile` and set the same environment variable.
