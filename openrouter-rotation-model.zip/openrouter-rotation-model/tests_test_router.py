import asyncio, json, httpx
from llm_router import OpenRouterClient, RouterConfig

def test_failover():
    calls=[]
    def handler(req):
        body=json.loads(req.content); calls.append(body['model'])
        if body['model']=='bad/model': return httpx.Response(429, text='rate')
        return httpx.Response(200, json={'model':'good/model','choices':[{'message':{'content':'ok'}}]})
    config=RouterConfig(api_keys=['x'], models=['bad/model','good/model'], max_retries_per_route=0)
    async def run():
        async with OpenRouterClient(config, transport=httpx.MockTransport(handler)) as c:
            r=await c.ask('hi'); assert r.content=='ok'
    asyncio.run(run()); assert calls==['bad/model','good/model']
